import sys; sys.path.insert(0,'/app')
import psycopg2, json, time

while True:
    try:
        conn=psycopg2.connect('host=postgres dbname=quantdinger user=quantdinger password=quantdinger123')
        cur=conn.cursor()
        cur.execute('SELECT id, trading_config FROM qd_strategies_trading')
        fixed=0
        for r in cur.fetchall():
            sid=r[0]; tc=json.loads(r[1])
            act=float(tc.get('trailing_activation_pct',0))
            trail=float(tc.get('trailing_stop_pct',0))
            om=tc.get('order_mode','')
            # 只修4H+15M+5M策略参数不对的
            code=tc.get('strategy_name','')
            changed=False
            if abs(act-7.2)>0.5 and tc.get('strategy_name',''):
                tc['trailing_activation_pct']=7.2; changed=True
            if abs(trail-3.0)>0.5 and tc.get('strategy_name',''):
                tc['trailing_stop_pct']=3.0; changed=True
            if om not in ('limit',''):
                tc['order_mode']='limit'; changed=True
            if tc.get('stop_loss_pct',0)!=5:
                tc['stop_loss_pct']=5; changed=True
            if tc.get('entry_pct',0)!=0.5:
                tc['entry_pct']=0.5; changed=True
            if changed:
                cur.execute('UPDATE qd_strategies_trading SET trading_config=%s WHERE id=%s', (json.dumps(tc), sid))
                fixed+=1
        if fixed:
            conn.commit()
            print(f'Auto-fix: {fixed} strategies corrected')
        conn.close()
    except Exception as e:
        print(f'Auto-fix error: {e}')
    time.sleep(30)
