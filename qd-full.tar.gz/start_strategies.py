import sys; sys.path.insert(0,'/app')
import psycopg2, time

conn=psycopg2.connect('host=postgres dbname=quantdinger user=quantdinger password=quantdinger123')
cur=conn.cursor()
for sid in [431,432,433,434,435,436]:
    cur.execute('UPDATE qd_strategies_trading SET status=%s WHERE id=%s', ('running', sid))
conn.commit(); conn.close()

from app.services.trading_executor import TradingExecutor
ex = TradingExecutor()
for sid in [431,432,433,434,435,436]:
    ok = ex.start_strategy(sid)
    print(f'#{sid} {"OK" if ok else "FAIL"}')

print(f'Strategy runner started ({len([s for s in [431,432,433,434,435,436] if True])} strategies)')
while True:
    time.sleep(60)
